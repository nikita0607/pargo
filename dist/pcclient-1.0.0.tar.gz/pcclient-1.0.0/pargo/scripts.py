def main(*args, **kwargs):
    print(args, kwargs)