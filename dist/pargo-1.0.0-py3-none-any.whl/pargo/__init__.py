try:
	import core
except:
	from . import core