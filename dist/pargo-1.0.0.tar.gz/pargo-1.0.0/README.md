# Pargo

This is a package manager for `Python`.

## Commands

1. new

Create new python project

```shell
pargo new ProjectName
```

2. installr

Install requirements from dir

```shell
pargo installr
```